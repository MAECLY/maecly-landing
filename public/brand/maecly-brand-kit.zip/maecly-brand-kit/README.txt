MAECLY brand kit

Concept 02 "Celdas": a lowercase m built from 14 cells on a 5x4 grid.
Petrol #0B3D45 · Paper #F4F1E8 · Quito #F2C230 · Ink #0E1A1C
Dark: Petrol lift #14525C · Quito bright #FFD100 · Night #0A1012
Type: Inter Tight (display), Inter (text), JetBrains Mono (mono)

Clear space: one cell (12.5% of the symbol) on every side.
Minimum: 24 px for the cell grid; use symbol-solid-16.svg at 16 px.
Wordmark: at least 72 px wide.
Don't recolor, stretch, rotate or add effects to the mark.

Free to use when writing about MAECLY and its products.
The name and logos are marks of Miguel Angel Esparza Calero (MAECLY).
All rights reserved. Guidelines: https://maecly.com/en/brand · hola@maecly.com
